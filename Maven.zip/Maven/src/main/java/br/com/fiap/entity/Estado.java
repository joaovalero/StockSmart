package br.com.fiap.entity;

public enum Estado {

}
