package br.com.fiap.entity;

import javax.persistence.Persistence;

public class Teste {

	public static void main(String[] args) {
		Persistence.createEntityManagerFactory("smartcities.maven").createEntityManager();

	}

}