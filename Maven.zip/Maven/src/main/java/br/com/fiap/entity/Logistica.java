package br.com.fiap.entity;

import java.util.Calendar;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "tb_logistica")

public class Logistica {

	@Id
	@Column(name = "cd_logistica")
	@SequenceGenerator(name = "logistica", sequenceName = "sq_td_logistica", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "logistica")
	private int codigo;

	@Column(name = "nm_endereco", nullable = false, length = 50)
	private String endereco;

	@Column(name = "nm_trasp", nullable = false, length = 50)
	private String transportadora;

	@CreationTimestamp
	@Column(name = "dt_entrega")
	private Calendar dataEntrega;

	@UpdateTimestamp
	@Column(name = "dt_despacho")
	private Calendar dataDespacho;
	
	
	@OneToMany(mappedBy = "logistica") 
	private List<Clientes> clientes;
	
	
	public Logistica() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getTransportadora() {
		return transportadora;
	}

	public void setTransportadora(String transportadora) {
		this.transportadora = transportadora;
	}

	public Calendar getDataEntrega() {
		return dataEntrega;
	}

	public void setDataEntrega(Calendar dataEntrega) {
		this.dataEntrega = dataEntrega;
	}

	public Calendar getDataDespacho() {
		return dataDespacho;
	}

	public void setDataDespacho(Calendar dataDespacho) {
		this.dataDespacho = dataDespacho;
	}

	
	
}
